<template>
  <div id="app">
    <header>
      <nav>
        <router-link to="/">Home</router-link>
        <router-link to="/locations">Locations</router-link>
      </nav>
    </header>
    <main>
      <router-view />
    </main>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'App',
})
</script>

<style scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  color: #2c3e50;
  margin: 0;
  padding: 0;
}
header {
  background: #282c34;
  padding: 12px 20px;
}
nav {
  display: flex;
  gap: 16px;
}
nav a {
  color: #61dafb;
  text-decoration: none;
}
nav a.router-link-active {
  font-weight: bold;
}
main {
  padding: 16px;
}
</style>
