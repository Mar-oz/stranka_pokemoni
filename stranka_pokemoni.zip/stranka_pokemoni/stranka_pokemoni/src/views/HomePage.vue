<template>
  <div class="home-page">
    <h1>Pokédex</h1>
    <div class="filters">
      <input v-model="searchTerm" placeholder="Search pokemon" />
      <select v-model="selectedType">
        <option value="">All types</option>
        <option v-for="(type, index) in typeOptions" :key="index" :value="type">{{ type }}</option>
      </select>
    </div>

    <div>
      <div v-if="filteredPokemons.length === 0">No pokemon found</div>
      <div v-else>
        <PokemonCard v-for="(pokemon, index) in filteredPokemons" :key="index" :pokemon="pokemon" />
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import PokemonCard from '../components/PokemonCard.vue'

export default defineComponent({
  name: 'HomePage',
  components: { PokemonCard },
  data() {
    return {
      pokemons: [] as any[],
      filteredPokemons: [] as any[],
      searchTerm: '',
      selectedType: '',
      typeOptions: ['grass', 'fire', 'water', 'flying', 'bug', 'normal', 'electric'],
    }
  },
  mounted() {
    console.log('mounted home')
    this.loadStuff()
  },
  watch: {
    searchTerm() {
      this.updateFiltered()
    },
    selectedType() {
      this.updateFiltered()
    },
  },
  methods: {
    updateFiltered() {
      const search = this.searchTerm.toLowerCase().trim()
      this.filteredPokemons = this.pokemons.filter((pokemon) => {
        const name = pokemon.name || ''
        const matchSearch = name.includes(search)
        let matchType = true
        if (this.selectedType) {
          const types = pokemon.types || []
          matchType = types.some((type: any) => type.type.name === this.selectedType)
        }
        return matchSearch && matchType
      })
    },
    loadStuff() {
      const cached = localStorage.getItem('pokemon-list')
      if (cached) {
        try {
          this.pokemons = JSON.parse(cached)
          this.filteredPokemons = this.pokemons
          console.log('loaded cached pokemons', this.pokemons.length)
          return
        } catch (error) {
          console.log('cache parse error', error)
        }
      }
      fetch('https://pokeapi.co/api/v2/pokemon?limit=75')
        .then((res) => res.json())
        .then((data) => {
          console.log('home fetch response', data)
          const results = data.results || []
          const promises = results.map((item: any) => fetch(item.url).then((r) => r.json()))
          return Promise.all(promises)
        })
        .then((list) => {
          this.pokemons = list
          this.filteredPokemons = list
          localStorage.setItem('pokemon-list', JSON.stringify(list))
          console.log(this.pokemons)
        })
        .catch((error) => {
          console.log('error loading pokemons', error)
        })
    },
  },
})
</script>

<style scoped>
.home-page {
  max-width: 900px;
  margin: 0 auto;
  padding: 20px;
}
.filters {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}
.filters input,
.filters select {
  padding: 8px;
  border: 1px solid #ccc;
}
</style>
