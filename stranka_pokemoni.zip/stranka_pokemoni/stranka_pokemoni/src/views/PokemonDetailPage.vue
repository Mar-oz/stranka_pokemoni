<template>
  <div class="detail-page">
    <button @click="$router.push({ name: 'Home' })">Back to listing</button>
    <div>
      <div v-if="pokemon">
        <h1>{{ pokemon.name }}</h1>
        <img v-if="pokemon.sprites" :src="pokemon.sprites.front_default" alt="sprite" />
        <p>Height: {{ pokemon.height }} | Weight: {{ pokemon.weight }}</p>
        <div class="types">
          <span v-for="(type, index) in pokemon.types" :key="index">{{ type.type.name }}</span>
        </div>
        <div class="stats">
          <div v-for="(stat, index) in pokemon.stats" :key="index">
            {{ stat.stat.name }}: {{ stat.base_stat }}
          </div>
        </div>
        <div class="abilities">
          <h3>Abilities</h3>
          <div v-for="(ability, index) in pokemon.abilities" :key="index">{{ ability.ability.name }}</div>
        </div>
        <div class="moves">
          <h3>Moves</h3>
          <div v-for="(move, index) in pokemon.moves.slice(0, 10)" :key="index">{{ move.move.name }}</div>
        </div>
        <div class="evolution" v-if="evolutionChain.length">
          <h3>Evolution Chain</h3>
          <div v-for="(name, index) in evolutionChain" :key="index">{{ name }}</div>
        </div>
        <div class="navigation">
          <button @click="goPrev">Prev</button>
          <button @click="goNext">Next</button>
        </div>
      </div>
      <div v-else>
        <p>No Pokemon found.</p>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'PokemonDetailPage',
  data() {
    return {
      pokemon: null as any,
      species: null as any,
      evolutionChain: [] as string[],
    }
  },
  mounted() {
    console.log('detail mounted')
    this.loadPokemon()
  },
  watch: {
    '$route.params.id'() {
      this.loadPokemon()
    },
  },
  methods: {
    loadPokemon() {
      const id = (this as any).$route.params.id
      if (!id) {
        return
      }
      const cacheKey = 'pokemon-detail-' + id
      const cached = localStorage.getItem(cacheKey)
      if (cached) {
        try {
          this.pokemon = JSON.parse(cached)
          this.loadSpecies(this.pokemon.species.url)
          return
        } catch (error) {
          console.log('detail cache error', error)
        }
      }
      fetch(`https://pokeapi.co/api/v2/pokemon/${id}`)
        .then((res) => res.json())
        .then((data) => {
          console.log('pokemon detail response', data)
          this.pokemon = data
          localStorage.setItem(cacheKey, JSON.stringify(data))
          this.loadSpecies(data.species.url)
        })
        .catch((error) => {
          console.log('detail fetch error', error)
        })
    },
    loadSpecies(url: string) {
      if (!url) {
        return
      }
      const cacheKey = 'species-' + (this as any).$route.params.id
      const cached = localStorage.getItem(cacheKey)
      if (cached) {
        try {
          this.species = JSON.parse(cached)
          this.loadEvolution(this.species.evolution_chain.url)
          return
        } catch (error) {
          console.log('species cache error', error)
        }
      }
      fetch(url)
        .then((res) => res.json())
        .then((data) => {
          console.log('species response', data)
          this.species = data
          localStorage.setItem(cacheKey, JSON.stringify(data))
          this.loadEvolution(data.evolution_chain.url)
        })
        .catch((error) => {
          console.log('species load error', error)
        })
    },
    loadEvolution(url: string) {
      if (!url) {
        return
      }
      const cacheKey = 'evolution-' + (this as any).$route.params.id
      const cached = localStorage.getItem(cacheKey)
      if (cached) {
        try {
          this.evolutionChain = JSON.parse(cached)
          return
        } catch (error) {
          console.log('evolution cache parse', error)
        }
      }
      fetch(url)
        .then((res) => res.json())
        .then((data) => {
          console.log('evolution response', data)
          this.evolutionChain = []
          let chain = data.chain
          while (chain) {
            if (chain.species) {
              this.evolutionChain.push(chain.species.name)
            }
            chain = chain.evolves_to && chain.evolves_to[0]
          }
          localStorage.setItem(cacheKey, JSON.stringify(this.evolutionChain))
        })
        .catch((error) => {
          console.log('evolution fetch error', error)
        })
    },
    goPrev() {
      const id = parseInt((this as any).$route.params.id, 10)
      if (id > 1) {
        ;(this as any).$router.push({ name: 'PokemonDetail', params: { id: id - 1 } })
      }
    },
    goNext() {
      const id = parseInt((this as any).$route.params.id, 10)
      if (id < 1000) {
        ;(this as any).$router.push({ name: 'PokemonDetail', params: { id: id + 1 } })
      }
    },
  },
})
</script>

<style scoped>
.detail-page {
  padding: 20px;
}
.types span {
  margin-right: 8px;
  background: #eee;
  padding: 4px 8px;
}
.stats, .abilities, .moves, .evolution {
  margin-top: 16px;
  padding: 10px;
  border: 1px solid #ddd;
  background: #fbfbfb;
}
.navigation {
  margin-top: 20px;
}
.navigation button {
  margin-right: 10px;
  padding: 8px 12px;
}
</style>
