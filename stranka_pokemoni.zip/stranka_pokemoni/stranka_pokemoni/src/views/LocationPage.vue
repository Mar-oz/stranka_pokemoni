<template>
  <div class="location-page">
    <h1>Locations</h1>
    <div class="location-list-area">
      <div class="location-list">
        <LocationCard
          v-for="(item, index) in locations"
          :key="index"
          :location="item"
          @select="showLocation"
        />
      </div>
      <div class="location-detail">
        <div v-if="selectedLocation">
          <h2>{{ selectedLocation.name }}</h2>
          <p>Areas: {{ selectedLocation.areas?.length || 0 }}</p>
          <div>
            <div v-if="selectedLocation.areas && selectedLocation.areas.length">
              <div
                v-for="(area, index) in selectedLocation.areas"
                :key="index"
                class="area-item"
                @click="loadArea(area)"
              >
                {{ area.name }}
              </div>
              <div v-if="areaPokemons.length">
                <h3>Pokémon in selected area</h3>
                <div v-for="(poke, index) in areaPokemons" :key="index" class="spawn-item" @click="gotoPokemon(poke.pokemon.name)">
                  {{ poke.pokemon.name }}
                </div>
              </div>
            </div>
            <div v-else>No areas to show</div>
          </div>
        </div>
        <div v-else>
          <p>Select a location to see details</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import LocationCard from '../components/LocationCard.vue'

export default defineComponent({
  name: 'LocationPage',
  components: { LocationCard },
  data() {
    return {
      locations: [] as any[],
      selectedLocation: null as any,
      areaPokemons: [] as any[],
    }
  },
  mounted() {
    console.log('mounted locations')
    this.getData()
  },
  methods: {
    getData() {
      const cached = localStorage.getItem('location-list')
      if (cached) {
        try {
          this.locations = JSON.parse(cached)
          return
        } catch (error) {
          console.log('invalid cache', error)
        }
      }
      fetch('https://pokeapi.co/api/v2/location?limit=20')
        .then((res) => res.json())
        .then((data) => {
          console.log('locations response', data)
          const result = data.results || []
          const promises = result.map((item: any) => fetch(item.url).then((r) => r.json()))
          return Promise.all(promises)
        })
        .then((list) => {
          this.locations = list
          localStorage.setItem('location-list', JSON.stringify(list))
        })
        .catch((error) => {
          console.log('location fetch error', error)
        })
    },
    showLocation(location: any) {
      this.selectedLocation = location
      this.areaPokemons = []
      // not sure why this is necessary but it works
      if (location.areas && location.areas.length) {
        this.loadArea(location.areas[0])
      }
    },
    loadArea(area: any) {
      const cached = localStorage.getItem('area-' + area.name)
      if (cached) {
        try {
          this.areaPokemons = JSON.parse(cached)
          return
        } catch (error) {
          console.log('area cache bad', error)
        }
      }
      fetch(area.url)
        .then((res) => res.json())
        .then((data) => {
          console.log('area response', data)
          this.areaPokemons = data.pokemon_encounters || []
          localStorage.setItem('area-' + area.name, JSON.stringify(this.areaPokemons))
        })
        .catch((error) => {
          console.log('area load error', error)
        })
    },
    gotoPokemon(name: string) {
      ;(this as any).$router.push({ name: 'PokemonDetail', params: { id: name } })
    },
  },
})
</script>

<style scoped>
.location-page {
  padding: 20px;
}
.location-list-area {
  display: flex;
  gap: 20px;
}
.location-list {
  width: 40%;
}
.location-detail {
  width: 55%;
  border: 1px solid #ccc;
  padding: 12px;
  background: #fff;
}
.area-item,
.spawn-item {
  padding: 8px;
  border-bottom: 1px solid #eee;
  cursor: pointer;
}
.area-item:hover,
.spawn-item:hover {
  background: #f7f7f7;
}
</style>
