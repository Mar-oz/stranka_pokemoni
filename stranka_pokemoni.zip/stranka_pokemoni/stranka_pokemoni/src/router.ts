import { createRouter, createWebHistory } from 'vue-router'
import HomePage from './views/HomePage.vue'
import LocationPage from './views/LocationPage.vue'
import PokemonDetailPage from './views/PokemonDetailPage.vue'

const routes = [
  { path: '/', name: 'Home', component: HomePage },
  { path: '/locations', name: 'Locations', component: LocationPage },
  { path: '/pokemon/:id', name: 'PokemonDetail', component: PokemonDetailPage },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router
