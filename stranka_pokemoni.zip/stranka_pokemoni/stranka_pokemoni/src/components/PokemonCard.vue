<template>
  <div class="pokemon-card" @click="handleClick">
    <img v-if="pokemon.sprites" :src="pokemon.sprites.front_default" alt="pokemon image" />
    <div class="pokemon-info">
      <h3>{{ pokemon.name }}</h3>
      <p v-if="pokemon.types">Type: {{ typeText }}</p>
      <p v-else>Loading type...</p>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'PokemonCard',
  props: {
    pokemon: { type: Object, required: true },
  },
  computed: {
    typeText() {
      const types = (this as any).pokemon.types || []
      return types.map((t: any) => t.type.name).join(', ')
    },
  },
  methods: {
    handleClick() {
      const id = (this as any).pokemon.id || (this as any).pokemon.name
      ;(this as any).$router.push({ name: 'PokemonDetail', params: { id } })
    },
  },
})
</script>

<style scoped>
.pokemon-card {
  display: flex;
  align-items: center;
  padding: 10px;
  border: 1px solid #ccc;
  cursor: pointer;
  margin-bottom: 10px;
  background: #fafafa;
}
.pokemon-card img {
  width: 56px;
  height: 56px;
  margin-right: 12px;
}
.pokemon-info h3 {
  margin: 0;
  font-size: 16px;
}
</style>
