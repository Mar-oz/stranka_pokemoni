<template>
  <div class="location-card" @click="selectLocation">
    <h4>{{ location.name }}</h4>
    <p>Area count: {{ location.area_count }}</p>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'LocationCard',
  props: {
    location: { type: Object, required: true },
  },
  methods: {
    selectLocation() {
      ;(this as any).$emit('select', (this as any).location)
    },
  },
})
</script>

<style scoped>
.location-card {
  padding: 10px;
  border: 1px solid #bbb;
  margin-bottom: 8px;
  background: #fff;
}
.location-card:hover {
  background: #f0f0f0;
}
</style>
